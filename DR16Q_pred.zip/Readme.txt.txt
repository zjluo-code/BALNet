DR16Q new catalog format
-------------------------------------------------------------------------------------------------------------------------------
Column		Name						Format		Description
-------------------------------------------------------------------------------------------------------------------------------
1			SDSS_NAME					A25			SDSS-DR16 designation hhmmss.ss+ddmmss.s (J2000)
2			RA							F11.6		Right Ascension in decimal degrees (J2000)
3			DEC							F11.6		Declination in decimal degrees (J2000)
4			PLATE						I6			Spectroscopic Plate number
5			MJD							I6			Spectroscopic MJD
6			FIBERID						I6			Spectroscopic Fiber number
7			Z							F9.4			Best available redshift 
-------------------------------------------------------------------------------------------------------------------------------
8			FLAG						I2			BAL flag (=0 : non-BAL quasars; = 1: BAL quasars)
9			NBAL						I3			number of CIV troughs of width larger than 1000 km/s
10			SNR_MEDIAN_1400_1600		F9.4			the median S/N in the window 1400-1600 Å (rest frame)
11			VMAX						9 * D		Maximum velocity of the CIV troughs
12			VMIN						9 * D		Minimum velocity of the CIV troughs 
-------------------------------------------------------------------------------------------------------------------------------
The columns 1-7 are obtained from the SDSS DR16_v4.fits (Lyke, et al. 2020). Download from SDSS
The columns 11-12  has a fixed length of 9. The value -1 indicates unavailable measurement, and others are double type (F25.16).